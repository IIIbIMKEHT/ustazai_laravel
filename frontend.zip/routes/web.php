<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\LoadPDFController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'auth:web'], function () {
    Route::get('/', function () {
        return view('welcome');
    })->name('chat');

    Route::get('load-pdf', [LoadPDFController::class, 'index'])->name('pdf-load');

    Route::get('logout', [AuthController::class, 'logout'])->name('logout');
});

Route::group(['prefix' => 'auth'], function () {
    Route::get('login', [AuthController::class, 'login'])->name('login');
    Route::get('google', [AuthController::class, 'google'])->name('auth.google');
    Route::get('google-callback', [AuthController::class, 'googleCallback'])->name('auth.google-callback');
});
