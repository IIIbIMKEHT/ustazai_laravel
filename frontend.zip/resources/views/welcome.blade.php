@extends('layout.default')
@section('content')
    <!-- Main Content Wrapper -->
    <livewire:chat />
@endsection
