<?php $__env->startSection('content'); ?>
    <!-- Main Content Wrapper -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('chat', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1338456226-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nurbakyt/Desktop/rag_front/resources/views/welcome.blade.php ENDPATH**/ ?>